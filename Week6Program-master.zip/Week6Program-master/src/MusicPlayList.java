import java.io.File;
import java.util.*;
import java.io.*;

public class MusicPlayList implements MusicPlayListInterface {
    public ArrayList<String> artists = new ArrayList<String>();
    public ArrayList<String> songName = new ArrayList<String>();
    public ArrayList<String> albumName = new ArrayList<String>();
    public MusicPlayList(){

    }

    @Override
    public boolean addEntry(String artistName, String songTitle, String albumTitle) {
        try {
            artists.add(artistName);
            songName.add(songTitle);
            albumName.add(albumTitle);
        }catch(IllegalArgumentException e){
            System.out.println(e);
            return false;
        }
        return true;
    }

    @Override
    public boolean deleteEntry(String artistName, String songTitle, String albumTitle) {

        try{
            for(int i = 0; i<artists.size(); i++){
                if(artists.get(i).contains(artistName) && songName.get(i).contains(songTitle)
                        && albumName.get(i).contains(albumTitle)){
                    artists.remove(i);
                    songName.remove(i);
                    albumName.remove(i);
                    return true;
                }
            }
        }catch(IllegalArgumentException e){
            System.out.println(e);
        }

        return false;
    }

    @Override
    public int save(File file) throws IllegalArgumentException {
        int size = 0;
        try {
                FileWriter csvWriter = new FileWriter(file);
                for (int i = 0;i <artists.size(); i++) {
                    csvWriter.write(artists.get(i) + ", " + songName.get(i) + ", " + albumName.get(i) + "\n");
                    size++;
                }
            csvWriter.flush();
            csvWriter.close();
            }catch(IOException e){
                System.out.println(e);
                return -1;
            }

        return size;
    }

    @Override
    public int load(File file) throws IllegalArgumentException{
        String line = "";
        String splitBy = ",";
        int iterations = 0;
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null)
            {
                String[] employee = line.split(splitBy);
                artists.set(iterations, employee[0]);
                songName.set(iterations, employee[0]);
                albumName.set(iterations, employee[0]);// use comma as separator
                iterations++;
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return -1;
        }
        return iterations;

    }
}
