import jdk.jfr.StackTrace;

import java.io.*;
import org.junit.*;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class MusicPlayListTest {
    public MusicPlayList playList = new MusicPlayList();
    public static void main(String[]args){
    }
    @Test
    public void FirstTest(){
        assertTrue(playList.addEntry("Beatles", "Yellow Submarine", "Yellow Submarine"));

    }
    @Test
    public void SecondTest(){
        assertTrue(playList.addEntry("Smash Mouth", "All star", "Astrolounge"));
    }
    @Test
    public void ThirdTest(){
        playList.addEntry("Smash Mouth", "All star", "Astrolounge");
        playList.addEntry("Beatles", "Yellow Submarine", "Yellow Submarine");
        playList.addEntry("Beatles", "A day in the life", "Sgt. Pepper’s Lonely Hearts Club Band");
        assertTrue(playList.deleteEntry("Smash Mouth", "All star", "Astrolounge"));
    }
    @Test
    public void FourthTest(){
        playList.addEntry("Beatles", "Yellow Submarine", "Yellow Submarine");
        playList.addEntry("Beatles", "A day in the life", "Sgt. Pepper’s Lonely Hearts Club Band");
        assertEquals(2, playList.save(new File("TestFile.csv")));
    }
    @Test
    public void FifthTest(){
        File file = new File("TestFile.csv");
        playList.addEntry("Beatles", "Yellow Submarine", "Yellow Submarine");
        playList.addEntry("Beatles", "A day in the life", "Sgt. Pepper’s Lonely Hearts Club Band");
       playList.save(file);
        assertEquals(2, playList.load(file));
    }

}
